"use client";

import { useLocale } from "next-intl";
import { Link, usePathname } from "@/i18n/navigation";
import { routing, type AppLocale } from "@/i18n/routing";
import { cn } from "@/lib/utils";

const FLAGS: Record<AppLocale, { src: string; alt: string }> = {
  es: { src: "/flags/spanish.png", alt: "Español" },
  en: { src: "/flags/usa.svg", alt: "English" },
};

export function LanguageSwitcher({ dark = false }: { dark?: boolean }) {
  const activeLocale = useLocale();
  const pathname = usePathname();

  return (
    <div
      className={cn(
        "flex items-center gap-1 rounded-full border p-1",
        dark ? "border-line-dark" : "border-line",
      )}
    >
      {routing.locales.map((locale) => {
        const flag = FLAGS[locale];
        const isActive = locale === activeLocale;
        return (
          <Link
            key={locale}
            href={pathname}
            locale={locale}
            aria-label={flag.alt}
            aria-current={isActive}
            title={flag.alt}
            className={cn(
              "flex h-6 w-6 items-center justify-center overflow-hidden rounded-full transition-all",
              isActive
                ? "opacity-100 ring-2 ring-signal-400"
                : "opacity-45 grayscale hover:opacity-80 hover:grayscale-0",
            )}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={flag.src}
              alt={flag.alt}
              className="h-full w-full object-cover"
            />
          </Link>
        );
      })}
    </div>
  );
}
