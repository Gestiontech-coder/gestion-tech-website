import { getTranslations } from "next-intl/server";
import { MapPin, ShieldCheck, FileCheck2 } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";

export async function Coverage() {
  const t = await getTranslations("coverage");

  const points = [
    { key: "point1", icon: MapPin },
    { key: "point2", icon: ShieldCheck },
    { key: "point3", icon: FileCheck2 },
  ] as const;

  return (
    <section id="cobertura" className="bg-paper-50 py-24">
      <div className="mx-auto grid max-w-6xl gap-14 px-5 sm:px-8 lg:grid-cols-[0.85fr_1.15fr] lg:gap-20">
        <Reveal>
          <h2 className="text-2xl font-semibold tracking-tight text-ink-900 sm:text-3xl">
            {t("heading")}
          </h2>
          <p className="mt-4 max-w-md text-[15px] leading-relaxed text-ink-700">
            {t("body")}
          </p>
        </Reveal>

        <div className="grid gap-8 sm:grid-cols-1">
          {points.map(({ key, icon: Icon }, i) => (
            <Reveal key={key} delay={i * 0.1} y={16}>
              <div className="flex gap-4 border-t border-line pt-6">
                <Icon
                  className="mt-0.5 h-5 w-5 shrink-0 text-brand-500"
                  strokeWidth={1.75}
                />
                <div>
                  <h3 className="font-medium text-ink-900">
                    {t(`${key}Title`)}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink-700">
                    {t(`${key}Body`)}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
