"use client";

import { motion, useReducedMotion } from "framer-motion";
import { useTranslations } from "next-intl";
import { ArrowRight } from "lucide-react";
import { SpectrumVisual } from "@/components/ui/SpectrumVisual";

export function Hero() {
  const t = useTranslations("hero");
  const reduceMotion = useReducedMotion();

  const fadeUp = {
    initial: reduceMotion ? undefined : { opacity: 0, y: 16 },
    animate: { opacity: 1, y: 0 },
  };

  return (
    <section className="relative overflow-hidden bg-navy-950 text-paper-0">
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(169,214,255,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(169,214,255,0.6) 1px, transparent 1px)",
          backgroundSize: "44px 44px",
        }}
      />

      <div className="relative mx-auto grid max-w-6xl gap-14 px-5 py-20 sm:px-8 sm:py-28 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
        <div>
          <motion.h1
            {...fadeUp}
            transition={{ duration: 0.55 }}
            className="max-w-lg text-[2.25rem] font-semibold leading-[1.15] tracking-tight sm:text-[2.75rem]"
          >
            {t("headline")}
          </motion.h1>

          <motion.p
            {...fadeUp}
            transition={{ duration: 0.55, delay: 0.08 }}
            className="mt-6 max-w-md text-[16px] leading-relaxed text-paper-100/75"
          >
            {t("subhead")}
          </motion.p>

          <motion.div
            {...fadeUp}
            transition={{ duration: 0.55, delay: 0.16 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <a
              href="#contacto"
              className="inline-flex items-center gap-2 rounded-full bg-signal-400 px-5 py-3 text-sm font-medium text-navy-950 transition-colors hover:bg-signal-300"
            >
              {t("ctaPrimary")}
              <ArrowRight className="h-4 w-4" strokeWidth={2} />
            </a>
            <a
              href="#servicios"
              className="inline-flex items-center gap-2 rounded-full border border-line-dark px-5 py-3 text-sm font-medium text-paper-0 transition-colors hover:border-paper-100/40"
            >
              {t("ctaSecondary")}
            </a>
          </motion.div>

          <motion.dl
            {...fadeUp}
            transition={{ duration: 0.55, delay: 0.24 }}
            className="mt-14 grid max-w-md grid-cols-3 gap-6 border-t border-line-dark pt-6"
          >
            {[
              { value: t("stat1Value"), label: t("stat1Label") },
              { value: t("stat2Value"), label: t("stat2Label") },
              { value: t("stat3Value"), label: t("stat3Label") },
            ].map((stat) => (
              <div key={stat.label}>
                <dt className="font-mono text-xl font-medium tabular-figures text-paper-0">
                  {stat.value}
                </dt>
                <dd className="mt-1 text-xs leading-snug text-paper-100/60">
                  {stat.label}
                </dd>
              </div>
            ))}
          </motion.dl>
        </div>

        <motion.div
          initial={reduceMotion ? undefined : { opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="border border-line-dark bg-navy-900/60 p-6 sm:p-8"
        >
          <SpectrumVisual />
        </motion.div>
      </div>
    </section>
  );
}
