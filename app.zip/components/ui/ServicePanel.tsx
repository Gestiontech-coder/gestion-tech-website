import type { LucideIcon } from "lucide-react";

export function ServicePanel({
  icon: Icon,
  index,
  title,
  description,
  metric,
}: {
  icon: LucideIcon;
  index: string;
  title: string;
  description: string;
  metric: string;
}) {
  return (
    <div className="group relative flex flex-col gap-5 bg-paper-0 p-7 transition-shadow hover:shadow-[inset_0_0_0_1px_var(--brand-500)]">
      <div className="flex items-start justify-between">
        <span className="flex h-11 w-11 items-center justify-center rounded-full border border-line text-navy-900 transition-colors group-hover:border-brand-500/50 group-hover:text-brand-500">
          <Icon className="h-5 w-5" strokeWidth={1.75} />
        </span>
        <span className="font-mono text-xs text-ink-500">{index}</span>
      </div>

      <div>
        <h3 className="text-lg font-semibold tracking-tight text-ink-900">
          {title}
        </h3>
        <p className="mt-2.5 text-[15px] leading-relaxed text-ink-700">
          {description}
        </p>
      </div>

      <div className="mt-auto border-t border-line pt-4 font-mono text-xs text-brand-500">
        {metric}
      </div>
    </div>
  );
}
